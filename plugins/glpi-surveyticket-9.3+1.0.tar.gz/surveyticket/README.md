# surveyticket
Plugin surveyticket for GLPI

This plugin permit to add a survey in place of description field of ticket like screenshot

![surveyticket](https://raw.githubusercontent.com/pluginsGLPI/surveyticket/master/screenshots/surveyticket.png "surveyticket")
